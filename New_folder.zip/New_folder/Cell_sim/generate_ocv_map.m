%% Function to generate OCV map for a cell

function [temp_vec,soc_vec,ocv_map] = generate_ocv_map(temp_vec,soc_vec,cell_data)

    %% Load cell data to generate OCV_map
    % load('P14_data.mat');

    %% Creating reference vectors
    ocv_map = zeros(length(soc_vec),length(temp_vec));
    
    %% Generating OCV_data
    for i = 1:1:length(soc_vec)
        for j = 1:1:length(temp_vec)
            ocv_map(i,j) = OCVfromSOCtemp(soc_vec(i),temp_vec(j),cell_data);
        end
    end

    %% Plotting
    figure;
    surf(temp_vec,soc_vec,ocv_map)
end
