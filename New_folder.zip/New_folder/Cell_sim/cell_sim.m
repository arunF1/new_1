clear all; close all; clc;

% Initialize some pack configuration parameters...
load P14_data.mat; % creates var. "model" with E2 cell parameter values
load load_profiles.mat

fprintf('\nStart Simulation\n');

time = load_profiles{1,3}.time; % seconds
load = load_profiles{1,3}.load; % in A

dt = 1; % sample time
module_simulation = 0;

ns = 12;      % Number of cells in series to make a stack
np = 3;       % Number of modules connected in parallel to make pack
nms = 8;      % Number of stacks connected in series to make a module
nmp = 1;      % Number of modules connected in parallel to make pack

Ns = ns * nms;
Np = np * nmp;

% Initialize some simulation configuration parameters...
t0 = 0; % Pack rests after time t0
maxtime = max(time) + t0; % Simulation run time in simulated seconds
t_amb = 25;
T = t_amb; % leave for vctorization

storez = zeros([maxtime Ns Np]);  % create storage for SOC
storei = zeros([maxtime Ns Np]);  % create storage for load
storev = zeros([maxtime Ns Np]);  % create storage for load
storeV = zeros([maxtime 1]);  % create storage for load
storev_diss_all = zeros([maxtime Ns Np]);  % create storage for load
storep_diss_all = zeros([maxtime Ns Np]);  % create storage for load
storeT = t_amb * ones([maxtime Ns Np]);  % create storage for load

% Thermal parameters



% finish thermal parameters

% Initialize states for ESC cell model


model = cell_data;
init_soc = 0.95;
z  = init_soc * ones(Ns,Np);
irc = zeros(Ns,Np);

% Default initialization for cells within the pack
kvec = [0; maxtime+1]; % Iteration (time) vector for temp. profile
q    = getParamESC('QParam',T,model)*ones(Ns,Np);
rc   = exp(-1./abs(getParamESC('RCParam',T,model)))'*ones(Ns,Np);
r    = (getParamESC('RParam',T,model))';

r0   = getParamESC('R0Param',T,model)*ones(Ns,Np);
rt   = 0.000125; % 125 microOhm resistance for each tab

% Modified initialization for cell variability
% ------------------------------------------------------------------------
% Set individual random "initial SOC" values
if 1, % set to "if 1," to execute, or "if 0," to skip this code
  z=0.855+0.10*rand([Ns Np]); % rand. init. SOC for ea. cell
end

% Set individual random cell-capacity values
if 1, % set to "if 1," to execute, or "if 0," to skip this code
  q= 58.5 +rand([Ns Np]);      % random capacity for ea. cell
end

% Set individual random cell-resistance relationships
if 1, % set to "if 1," to execute, or "if 0," to skip this code
  r0 = 0.005+0.020*rand(Ns,Np);
end
r0 = r0 + 2*rt; % add tab resistance to cell resistance

% Add faults to pack: cells faulted open- and short-circuit
% ------------------------------------------------------------------------
% To delete a SCM (open-circuit fault), set a resistance to Inf
%r0(1,1) = Inf; % for example...

% To delete a cell from a SCM (short-circuit fault), set its SOC to NaN
%z(1,2) = NaN; % for example, delete cell 2 in SCM 1 
Rsc = 0.0025; % Resistance value to use for cell whose SOC < 0%

% Get ready to simulate... first compute pack capacity in Ah
totalCap = min(sum(q,2)); % pack capacity = minimum module capacity
if module_simulation == 1
    load = load/Np;
    fprintf('\nModule Simulation \n');
else
    fprintf('\nPack Simulation \n');
end


for k = 1:dt:maxtime
  I = load(k);  
  v = OCVfromSOCtemp(z,T,model); % get OCV for each cell: Ns * Np matrix
  v = v - r.*irc; % add in hysteresis and diffusion voltages
  %r0(isnan(z)) = Rsc; % s-c fault has "short-circuit" resistance
  V = (sum(sum(v,1)./sum(r0,1),2)-I)./sum(1./sum(r0,1),2); % Bus V
  ik = (sum(v,1)-repmat(V,1,Np))./sum(r0,1); % 1 * Np cell loads
  ik = repmat(ik,Ns,1);
  z = z - (1/3600)*ik./q;  % Update each cell SOC
  %z(z<0) = NaN; % set over-discharged cells to short-circuit fault
  irc = rc.*irc + (1-rc).*ik; % Update diffusion loads

  %if min(z(:)) < 0.05, break; end % stop discharging
  %if max(z(:)) > 0.95, break;  end % stop charging
  %if k>t0, I = 0; end % rest 
  
  
  storez(k,:,:) = z; % Store SOC for later plotting
  storei(k,:,:) = ik; % store load for later plotting
  storev(k,:,:) = v;
  %storevf(k,:,:) = v;
  storeV(k,1) = V;
  
end % for k

fprintf('\nSimulation completed\n');
%% Plotting results
% Plot some sample results. In Figure 1, plot the individual SOC vs. time
% for all cells in all series PCMs. There is one subplot for each SCM.
t = (0:(length(storez(:,:,1))-1))/60; 
%xplots = round(1.0*ceil(sqrt(Np))); yplots = ceil(Np/xplots);
xplots = 3;
yplots = 1;
figure(1); clf;
for k = 1:Np,
  subplot(yplots,xplots,k);
  zr=squeeze(100*storez(:,:,k));
  plot(t,zr); grid on;
  title(sprintf('SOC for cells in SCM %d',k),'fontsize',14); 
  axis([0 ceil(maxtime/60) 0 100]);
  ylabel('SOC (%)','fontsize',14); xlabel('Time (min)','fontsize',14); 
  grid on
end

% In Figure 2, plot the individual cell load vs. time for all 
% cells in all series PCMs. There is one subplot for each SCM.
figure(2); clf;
for k = 1:Np,
  subplot(yplots,xplots,k);
  zr=squeeze(storei(:,:,k));
  plot(t,zr); grid on
  axis([0 ceil(maxtime/60) -120.1 120.1]);
  title(sprintf('load for cells in SCM %d',k),'fontsize',14); 
  ylabel('load (A)','fontsize',14); xlabel('Time (min)','fontsize',14); 
  grid on
end

% In Figure 3, plot the difference between min SOC & max SOC with in SCM vs time 
% for all SCMs. There is one subplot for each SCM.


figure(3); clf;
for k = 1:Np,
  subplot(yplots,xplots,k);
  zr=squeeze(100*storez(:,:,k));
  max_1 = max(zr,[],2);
  min_1 = min(zr,[],2);
  avg_1 = mean(zr,2);
  diff = max_1 - min_1;
  plot(t,diff); grid on
  axis([0 ceil(maxtime/60) 0 100]);
  title(sprintf('Max SOC Diff within SCMs %d',k),'fontsize',14); 
  ylabel('SOC difference (%)','fontsize',14); xlabel('Time (min)','fontsize',14); 
  grid on
end